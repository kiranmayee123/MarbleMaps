package com.example.kiranmayee.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.nfc.Tag;
import android.provider.CalendarContract;
import android.util.Log;
import android.widget.Toast;

import com.example.kiranmayee.myapplication.DbContract.*;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;



public class DatabaseHelper extends SQLiteOpenHelper {
    private SQLiteDatabase db;
    private String TAG = MainActivityFragment.class.getSimpleName();
    public static final String DATABASE_NAME = "Student.db";
    // Database Version
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase db) {

        // create student table
        final String SQL_CREATE_ATTENDANCE_TABLE = " CREATE TABLE " + Login.TABLE_NAME + "(" +
                Login._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                Login.COLUMN_USER + " INTEGER NOT NULL, " +
                Login.COLUMN_TIMESTAMP + " DATETIME DEFAULT (datetime('now','localtime')),"+
                Login.COLUMN_LATITUDE + " DOUBLE NOT NULL, "+
                Login.COLUMN_LONGITUDE + " DOUBLE NOT NULL " +
                "); ";
        db.execSQL(SQL_CREATE_ATTENDANCE_TABLE);
    }
    // Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+Login.TABLE_NAME);
        onCreate(db);
    }
    public Cursor getAllData() {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] col={Login.COLUMN_USER,Login.COLUMN_TIMESTAMP,Login.COLUMN_LATITUDE,Login.COLUMN_LONGITUDE};
        Cursor cr=db.query(Login.TABLE_NAME,col,null,null,null,null,null);
        return cr;
    }
    public boolean updateData(int id, float st,double latitude,double longitude) {
        db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(Login.COLUMN_USER,id);
        values.put(Login.COLUMN_LATITUDE,latitude);
        values.put(Login.COLUMN_LONGITUDE,longitude);
        // updating row
        int a=db.update(Login.TABLE_NAME, values,"_id="+id, null);
        System.out.print(a);
        return true;
    }

    public void deleteData(String date) {
        db = this.getWritableDatabase();
        db.delete(Login.TABLE_NAME,"Date = ?",
                new String[]{date});
    }
    public boolean getdate()
    {
        db=this.getReadableDatabase();
        Cursor cr= db.rawQuery("SELECT * from login where day=curdate()",null);
        Log.e(TAG,cr.toString());
        return true;
    }


}